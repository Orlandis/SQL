Use the enclosed .SQL file in this ZIP folder to create the sample database
 described in the book samples.
You have to use Management Studio (see the description of this tool in Chapter 3)
 to start the SQL script
 and to *create the sample database* 
and all four tables that belong to the database.
 